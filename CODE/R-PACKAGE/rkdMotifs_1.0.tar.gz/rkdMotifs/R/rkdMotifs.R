kdistr <- setClass(
  # Set the name for the class
  "kdistr",
  
  # Define the slots
  slots = c(
    l = "integer",
    k = "integer",
    doubleStrand = "logical",
    estimated = "logical"
  ),
  contains = "dgCMatrix"
)

setMethod("[", c("kdistr"),function(x, i, j, ..., drop=TRUE){
  cat("MYMETHOD kdistr\n")
  if(!missing(i)){
    stop("cannot subset kdistr rows")
  }
  x<-kdistr(x@.Data[i,j,drop=FALSE],l=x@l,k=x@k,doubleStrand=x@doubleStrand,estimated=x@estimated)
  x
})



kdmotif <- setClass(
  # Set the name for the class
  "kdmotifs",
  
  # Define the slots
  slots = c(
    l = "integer",
    k = "integer",
    doubleStrand = "logical",
    estimated = "logical"
  ),
  contains = "matrix"
)

setMethod("show", "kdmotifs",function(object){
  cat("kdm motifs matrix\n")
  cat("\t#N motifs: ",ncol(object@.Data),"\n",sep="")
  cat("\tKmer length: ",object@l,"\n",sep="")
  cat("\tN# gaps: ",object@k,"\n",sep="")
  cat("\tDouble strand: ",object@doubleStrand,"\n",sep="")
})


setMethod("[", c("kdmotifs"),function(x, i, j, ..., drop=TRUE){
  if(!missing(i)){
    stop("cannot subset kdmotifs rows")
    }
  x@.Data<-x@.Data[i,j,drop=FALSE]
  ## less clever: update slot, return instance
  ## x@slt = x@slt[i]
  ## x
  ## clever: by default initialize is a copy constructor, too
  x
})

kdfeatures <- setClass(
  # Set the name for the class
  "kdfeatures",
  
  # Define the slots
  slots = c(
    l = "integer",
    k = "integer",
    doubleStrand = "logical",
    estimated = "logical"
  ),
  contains = "matrix"
)

setMethod("[", c("kdfeatures"),
          ## we won't support subsetting on j; dispatching on 'drop' doesn't
          ## make sense (to me), so in rebellion we'll quietly ignore it.
          function(x, i, j, ..., drop=TRUE)
          {
            x@.Data<-x@.Data[i,j,drop=FALSE]
            ## less clever: update slot, return instance
            ## x@slt = x@slt[i]
            ## x
            ## clever: by default initialize is a copy constructor, too
            x
          })





kdmodel <- setClass(
  # Set the name for the class
  "kdmodel",
  
  # Define the slots
  slots = c(
    coefficients = "matrix",
    intercept = "numeric"
  ),
  contains = "kdmotifs"
)


setMethod("show", c("kdmodel"),function(object){
  cat("kdm Model\n")
  cat("\tOutcomes: ",ncol(object@coefficients),"\n",sep="")
  cat("\tPredictors: ")
  show(as.kdmotifs(object))
})

setAs("kdmodel", "kdmotifs",function(from){
  m<-new("kdmotifs",from@.Data,l=from@l,k=from@k,doubleStrand=from@doubleStrand,estimated=from@estimated)
  m
})


setMethod("[", c("kdmodel"),
          ## we won't support subsetting on j; dispatching on 'drop' doesn't
          ## make sense (to me), so in rebellion we'll quietly ignore it.
          function(x, i, j, ..., drop=TRUE)
          {
            stop("cannot subset kdmodel")
          })

as.kdmotifs<-function(x){
  m<-new("kdmotifs",x@.Data,l=x@l,k=x@k,doubleStrand=x@doubleStrand,estimated=x@estimated)
  m
}


kpwm<-setClass(
  "kpwm",
  slots=c(
    background="numeric"
  ),
  contains = "matrix"
)

kpwmset<-setClass(
  "kpwmset",
  contains = "list"
)

kbed<-setClass(
  "kbed",
  slots=c(
    type = "character"
  ),
  contains = "data.frame"
)

setMethod("[", c("kbed"),
          ## we won't support subsetting on j; dispatching on 'drop' doesn't
          ## make sense (to me), so in rebellion we'll quietly ignore it.
          function(x, i, j, ..., drop=TRUE)
          {
            if(!missing(j)){
              stop("cannot subset kbed columns")
            }
            kbed(data.frame(x)[i,],type=x@type)
          })




.onLoad <- function(libname, pkgname){
  initPackage();
}


kdmReadBedFile<-function(filename,type,force.names=T){
  #df=readBedFile_internal(filename,type);
  kbed(readBedFile_internal(filename,type),type=type)
}

kdmTestConvertNarrowPeak<-function(filename){
  bed<-kdmReadBedFile(filename,type="narrowPeak")
  rr<-test_convert_internal(bed)
  rr
}


kdmRemoveOverlappingEntries<-function(bedData){
    kbed(remove_overlapping_internal(bedData,bedData@type),type=bedData@type)
  }

kdmGetSequence<-function(bedData,file.name){
  get_sequences_internal(bedData,bedData@type,file.name)
}

kdmBackground<-function(selected,excluded,nregions,ref,n.gcbins=20,n.rpbins=20){
  tret=background_internal(selected,selected@type,excluded,excluded@type,n.gcbins,n.rpbins,nregions,ref);
  list(sel=kbed(tret[[1]],type=selected@type),bkg=kbed(tret[[2]],type="bed6"))
}

kdmDistr<-function(data,kmerlength,ngaps,double.strand,estimate=FALSE,strict=FALSE,use.float=FALSE){
  res<-c();
  if(is.character(data)){
    res<-kdistr_internal(data,kmerlength,ngaps,double.strand,estimate,strict,use.float)
  }else{
    stop("data must be a sequence array")
  }
  res
}

kdmDistrProfile<-function(sequence,win,kmerlength,ngaps,double.strand,estimate=FALSE,strict=FALSE,use.float=FALSE){
  res<-c();
  if(is.character(sequence)){
    res<-kdistrProfile_internal(sequence,win,kmerlength,ngaps,double.strand,estimate,strict,use.float)
  }else{
    stop("data must be a sequence array")
  }
  res
}


kdmGkmersString<-function(kmerlength,ngaps,double.strand){
  ss<-kdmGkmersString_internal(kmerlength,ngaps,double.strand)
  if(double.strand){
    as.data.frame(ss)
  }else{
    as.data.frame(ss[[1]])
  }
}

kdmMotifs<-function(kdistr,rank,np,initialization,W0=NULL,clustering.method="complete",bhattacharyya=FALSE,init.only=FALSE,tolerance=1e-6,max.iter=20000,use.float=FALSE){
  res<-c();
  if(class(kdistr)=="kdistr"){
    if(!is.null(W0)){
      res<-kdmotifs_internal(kdistr,rank,np,initialization,W0,clustering.method,bhattacharyya,init.only,tolerance,max.iter,use.float)
    }else{
      res<-kdmotifs_internal(kdistr,rank,np,initialization,matrix(0,0,0),clustering.method,bhattacharyya,init.only,tolerance,max.iter,use.float)
    }
  }else{
    if(!is.null(W0)){
      res<-kdmotifs_internal_from_motifs(kdistr,rank,np,initialization,W0,clustering.method,bhattacharyya,init.only,tolerance,max.iter,use.float)
    }else{
      res<-kdmotifs_internal_from_motifs(kdistr,rank,np,initialization,matrix(0,0,0),clustering.method,bhattacharyya,init.only,tolerance,max.iter,use.float)
    }
    
  }
    res
}

kdmMotifsFromSequences<-function(sequences,kmerlength,ngaps,double.strand,estimate=FALSE,rank,np,initialization,W0=NULL,clustering.method="complete",bhattacharyya=FALSE,init.only=FALSE,tolerance=1e-6,max.iter=20000,use.float=FALSE){
  res<-c();
  if(!is.null(W0)){
    res<-kdmotifs_from_sequences_internal(sequences,kmerlength,ngaps,double.strand,estimate=FALSE,rank,np,initialization,W0,clustering.method,bhattacharyya,init.only,tolerance,max.iter,use.float)
  }else{
    res<-kdmotifs_from_sequences_internal(sequences,kmerlength,ngaps,double.strand,estimate=FALSE,rank,np,initialization,matrix(0,0,0),clustering.method,bhattacharyya,init.only,tolerance,max.iter,use.float)
  }
  res
}




kdmEstimateMotifs<-function(motifs,use.float=FALSE){
  kdmotifs_estimate_internal(motifs,use.float)
}

kdmMotifsFromPWM<-function(pwmSet,kmerlength,ngaps,double.strand=FALSE,pad.size=kmerlength,use.float=FALSE){
  res<-kdmotifsfrompwm_internal(pwmSet,kmerlength,ngaps,double.strand,pad.size,use.float)
  res
}

kdmMotifsFromPWM2<-function(pwmSet,kmerlength,ngaps,double.strand=FALSE,use.float=FALSE){
  res<-kdmotifsfrompwm2_internal(pwmSet,kmerlength,ngaps,double.strand,use.float)
  res
}

kdmGetPWMThresholds<-function(pwmSet,alpha,initialGranularity=1e-4,forcedGranularity=TRUE,maxGranularity=1e-10){
  thresholds<-kdmGetPWMThresholds_internal(pwmSet,alpha,initialGranularity,forcedGranularity,maxGranularity)
  thresholds
}


kdmMotifsReduce<-function(motifs,rank,tolerance=1e-6,max.iter=20000,use.float=FALSE){
  res<-kdmotifsReduce_internal(motifs,rank,tolerance,max.iter,use.float)
  res
}

kdmBuildModel<-function(motifs,coeffmatrix,intercept,remove.null.coeff=TRUE){
  if(!inherits(motifs,"kdmotifs")){
    stop("motifs must be coercible to a 'kdmotifs' object")
  }
  model<-NULL
  dc<-dim(coeffmatrix)
  dm<-dim(motifs)
  if(dc[1]!=dm[2]){
    stop("number of coefficients must equal the number of motifs")
  }
  if(missing(intercept)){
    intercept<-rep(0,dc[2])
  }else{
    if(length(intercept)!=dc[2]){
      stop("number of intercepts must be equal to the coedfficients columns")
    }
  }
  if(remove.null.coeff){
    sel<-which(apply(coeffmatrix,1,function(a){sum(a!=0)})>0)
    model<-new("kdmodel",motifs[,sel],coefficients=coeffmatrix[sel,,drop=F],intercept=intercept);
  }else{
    model<-new("kdmodel",motifs,coefficients=coeffmatrix,intercept=intercept);
  }
  model
}

kdmPredict<-function(model,data,predtype,bedType,genomeFile,strict=FALSE,use.float=FALSE){
  if(class(model)!="kdmodel") stop("model must be an objecct of class 'kdmodel'")
  ret<-NULL;
  if(class(data)=="character" & length(data)==1){
    stop("not yet implemented")
  }else if(class(data)=="kbed"){
    ret<-predict_internal_from_bed(model,data,bedType,genomeFile,strict,use.float);
  }else if(class(data)=="character" & length(data)>1){
    ret<-predict_internal_from_sequences(model,data,strict,use.float);
  }else if(class(data)=="kdistr"){
    ret<-predict_internal_from_kdistr(model,data,use.float);
  }else stop("data must be a string vector or a kbed oject or a kdistr object")
  
}

kdmFeatures<-function(motifs, data, strict=FALSE, use.float=FALSE){
  res<-c()
  dclass<-class(data)
  if(dclass=="kdistr"){
    res<-kdfeatures_internal_from_kdistr(motifs,data,use.float)
  }else if(dclass=="character" & length(data)>1){
    res<-kdfeatures_internal_from_seqs(motifs,data,strict,use.float)
  }
  res
}

kdmFeaturesProfile<-function(motifs, sequence, win, strict=FALSE, use.float=FALSE){
  kdfeatures_profile_internal(motifs,sequence,win,strict,use.float)
}


kdmMergeKdmotifs<-function(d1,d2){
  if(class(d1)=="list"){
    R<-matrix(0,nrow(d1[[1]]),sum(unlist(lapply(d1,ncol))))
    cc<-0;
    for(i in 1:length(d1)){
      nc<-ncol(d1[[i]]);
      R[,cc+(1:nc)]<-d1[[i]]@.Data;
      cc<-cc+nc
    }
    res<-new("kdmotifs",R,l=d1[[1]]@l,k=d1[[1]]@k,doubleStrand=d1[[1]]@doubleStrand,estimated=d1[[1]]@estimated)
  }else{
    res<-d1;
    if(!inherits(d1,"kdmotifs") ){
      stop("Objects d1 and d2 must both be either kdistr or kdmotifs")
    }else if( d1@l==d2@l & d1@k==d2@k & d1@doubleStrand==d2@doubleStrand ){
      res@.Data<-cbind(d1,d2)
    }else{
      stop("d1 and d2 are incopatible (i.e. differnt kmer length, differnt gap number or different strandness")
    }
  }
  res
}



kdmGetW0<-function(counts,clustering.method="complete",good.clusters=TRUE,min.rank,max.rank,bhattacharyya=FALSE,use.float=FALSE){
  kdmGetW0_internal(counts,clustering.method,good.clusters,min.rank,max.rank,bhattacharyya,use.float);
}


kdmRankInfo<-function(distance,clustering.method="complete",use.float=FALSE){
  kdmRankInfo_internal(distance,clustering.method,use.float)
}

kdmSilhouette<-function(distance,cluster.labels,use.float=FALSE){
  kdmSilhouette_internal(distance,cluster.labels,use.float)
}

kdmClusterMotifs<-function(motifs,labels,use.float=FALSE){
  rank<-max(labels)
  mmot<-kdmotifs_merge_internal(motifs,matrix(labels-1,length(labels),1),rank,use.float)
  mmot
}

kdmMergeKdistr<-function(d1,d2,use.float=FALSE){
}

kdmSimilarity<-function(d1,d2,use.float=FALSE){
  res<-NULL;
  if((class(d1)!=class(d2))|(class(d1)!="kdistr" & class(d1)!="kdmotifs")){
    error("Objects d1 and d2 must both be either kdistr or kdmotifs")
  }
  if(class(d1)=="kdistr"){
    res<-kdmSimilarity_kdistr_internal(d1,d2,use.float)
  }else if(class(d2)=="kdmotifs"){
    res<-kdmSimilarity_kdmotifs_internal(d1,d2,use.float)
  }
  res
}

kdmDistance<-function(d1,d2,bhattacharyya=FALSE,use.float=FALSE){
  res<-NULL;
  if(missing(d2)){
    if((class(d1)!="kdistr" & class(d1)!="kdmotifs")){    
      error("Objects d1 must be either kdistr or kdmotifs")
    }
    if(class(d1)=="kdistr"){
      res<-kdmDistance_kdistr_self_internal(d1,bhattacharyya,use.float)
    }else if(class(d1)=="kdmotifs"){
      res<-kdmDistance_kdmotifs_self_internal(d1,bhattacharyya,use.float)
    }
    
  }else{
    if((class(d1)!=class(d2))|(class(d1)!="kdistr" & class(d1)!="kdmotifs")){
      error("Objects d1 and d2 must both be either kdistr or kdmotifs")
    }
    if(class(d1)=="kdistr"){
      res<-kdmDistance_kdistr_internal(d1,d2,bhattacharyya,use.float)
    }else if(class(d2)=="kdmotifs"){
      res<-kdmDistance_kdmotifs_internal(d1,d2,bhattacharyya,use.float)
    }
  }
  res
}

kdmModelsCorrelation<-function(a,b=NULL,niter=0){
  if(is.null(b)){
    b=new("kdmodel")
  }
  if(class(a)=="list"){
    nmod<-length(a)
    res<-list(correlation=diag(nmod),p.values=diag(nmod))
    for(i in 1:(nmod-1)){
      for(j in (i+1):nmod){
        tmp<-kdmModelCorrelation_internal(a[[i]],a[[j]],niter);
        res$correlation[i,j]<-res$correlation[i,j]<-tmp$correlation
        res$p.values[i,j]<-res$p.values[i,j]<-tmp$p.values
        cat(i,j,res$correlation[i,j],"\n")
      }
    }
  }else{
    res<-kdmModelCorrelation_internal(a,b,niter);
  }
  res
}

kdmModelsCorrelation2<-function(a,b=NULL,niter=0){
  if(is.null(b)){
    b=new("kdmodel")
  }
  if(class(a)=="list"){
    nmod<-length(a)
    res<-list(correlation=diag(nmod),p.values=diag(nmod))
    for(i in 1:(nmod-1)){
      for(j in (i+1):nmod){
        tmp<-kdmModelCorrelation2_internal(a[[i]],a[[j]],niter);
        res$correlation[i,j]<-res$correlation[i,j]<-tmp$correlation
        res$p.values[i,j]<-res$p.values[i,j]<-tmp$p.values
        cat(i,j,res$correlation[i,j],"\n")
      }
    }
  }else{
    res<-kdmModelCorrelation2_internal(a,b,niter);
  }
  res
}



kdmFeaturesFromPWMSet<-function(sequences,pwmSet,double.strand=TRUE,mode="max"){
  kdmFeaturesFromPWMSet_internal(sequences,pwmSet,double.strand,mode);
}

kdmFeaturesProfileFromPWMSet<-function(sequence,pwmSet){
  kdmFeaturesProfileFromPWMSet_internal(sequence,pwmSet);
}





kdmMotifProfiles2<-function(data,centers,labels,motifs,half.interval,half.win,genome.file,strict=FALSE,use.float=FALSE){
  if(length(centers)==1){
    RES<-kdmMotifProfiles2_internal(data,rep(centers[1],nrow(data)),labels,motifs,half.interval,half.win,genome.file,strict,use.float)
  }else{
    RES<-kdmMotifProfiles2_internal(data,centers,labels,motifs,half.interval,half.win,genome.file,strict,use.float)
  }
  RES
}

kdmMotifProfiles3<-function(data,centers,labels,motifs,half.interval,half.win,genome.file,strict=FALSE,use.float=FALSE){
  if(length(centers)==1){
    RES<-kdmMotifProfiles3_internal(data,rep(centers[1],nrow(data)),labels,motifs,half.interval,half.win,genome.file,strict,use.float)
  }else{
    RES<-kdmMotifProfiles3_internal(data,centers,labels,motifs,half.interval,half.win,genome.file,strict,use.float)
  }
  RES
}

kdmMotifProfiles3_seq<-function(pseq,nseq,motifs,half.interval,half.win,strict=FALSE,use.float=FALSE){
  RES<-kdmMotifProfiles3_seq_internal(pseq,nseq,motifs,half.interval,half.win,strict,use.float)
  RES
}


kdmGetProfilesParameters<-function(profile,half.interval,half.win,nrep=100,max.selected.peak,half90.interval,use.float=FALSE){
  Am=kdmGetProfilesParameters_internal(profile,half.interval,half.win,nrep,max.selected.peak,half90.interval,use.float)
  colnames(Am)<-c("baseline","delta","peak","width","cor","aic","fmin","rsd","x95","class","selected","max")
  A<-as.data.frame(Am)
  classnames<-c("CENTRALLY ENRICHED","TWO MERGED PEAKS","TWO OVERLAPPING PEAKS","TWO DISTINCT PEAKS","CONSTANTLY ENRICHED","CENTRALLY DEPLETED","CONSTANTLY DEPLETED")    
  A$class<-as.factor(classnames[A$class])
  A$class<-ordered(A$class,levels=classnames)
  A
}

kdmMotifProfiles<-function(data,centers,labels,motifs,interval,win,maxSelectedPeak,half90interval,genome.file,nrep=100,use.float=FALSE){
  if(length(centers)==1){
    RES<-kdmMotifProfiles_internal(data,rep(centers[1],nrow(data)),labels,motifs,interval,win,nrep,maxSelectedPeak,half90interval,genome.file,use.float)
  }else{
    RES<-kdmMotifProfiles_internal(data,centers,labels,motifs,interval,win,nrep,maxSelectedPeak,half90interval,genome.file,use.float)
  }
  colnames(RES$parameters)<-c("baseline","delta","peak","width","cor","aic","fmin","rsd","x95","class","selected","max")
  RES$parameters<-as.data.frame(RES$parameters)
  
  classnames<-c("CENTRALLY ENRICHED","TWO MERGED PEAKS","TWO OVERLAPPING PEAKS","TWO DISTINCT PEAKS","CONSTANTLY ENRICHED","CENTRALLY DEPLETED","CONSTANTLY DEPLETED")  
  RES$parameters$class=as.factor(classnames[RES$parameters$class])
  RES$parameters$class<-ordered(RES$parameters$class,levels=classnames)
  
  RES
}

kdmAnnotateMotifs<-function(motifs,REF,nhits,normalizeSimilarity=FALSE){
  W<-as(motifs,"kdmotifs")
  refMotifs<-REF$W
  ANNOT<-REF$names
  
  S<-kdmSimilarity(W,refMotifs)
  if(normalizeSimilarity){
    SUP<-kdmSimilarity(refMotifs,refMotifs)
    diag(SUP)<-NA
    a<-apply(SUP,1,mean,na.rm=TRUE)
    for(i in 1:ncol(S)){
      S[,i]<-S[,i]/a[i]
    }
  }
  
  TFnames<-unique(unlist(strsplit(unlist(ANNOT),split=",")))
  tt<-matrix(0,ncol(W),length(TFnames))
  gg<-matrix(0,ncol(W),length(TFnames))
  sco<-matrix(0,ncol(W),length(TFnames))
  
  SR<--(t(apply(S,1,rank))-length(ANNOT))+1
  thresh<-max(S[upper.tri(S)])*nhits
  for(i in 1:ncol(W)){
    ss<-which(S[i,]>thresh)
    if(length(ss)>0){
      for(j in 1:length(ss)){
        cc<-match(ANNOT[[ss[j]]],TFnames)
        gg[i,cc]<-gg[i,cc]+SR[i,ss[j]]
        sco[i,cc]<-sco[i,cc]+S[i,ss[j]]
        tt[i,cc]<-tt[i,cc]+1
      }
    }
  }
  s1<-which(tt>0)
  gg[s1]<-gg[s1]/tt[s1]
  sco[s1]<-sco[s1]/tt[s1]
  
  annotations<-list()
  for(i in 1:nrow(tt)){
    aa<-max(tt[i,])
    if(aa>0){
      sel<-which(tt[i,]==max(tt[i,]))
      oo<-sel[order(gg[i,sel],decreasing=FALSE)]
      annotations[[i]]<-data.frame(name=TFnames[oo],num=tt[i,oo],rank=gg[i,oo],score=sco[i,oo])
    }else{
      annotations[[i]]<-data.frame(name=c())
    }
  }
  annotations
}


kdmPlotMotifProfiles<-function(motifs,P,REF,highlights=NULL,nhits=0.5,scale=FALSE,useModel=FALSE,normalizeSimilarity=FALSE,ecolors=c("darkblue","gray50","gold")){
  
  require(ComplexHeatmap)
  require(circlize)
  ismodel = (class(motifs)=="kdmodel")
  
  A<-P$parameters
  Y<-P$profile$Y
  pos<- P$profile$x
  
  sFF<-if(useModel){t(apply(as.matrix(A[,1:4]),1,function(a){a[1]+a[2]*(exp(-((pos-a[3])/a[4])^2) + exp(-((pos+a[3])/a[4])^2))}))}else{Y}
  sFF<-if(scale){t(scale(t(sFF)))}else{log2(sFF)}
  
  annotations<-kdmAnnotateMotifs(motifs,REF,nhits)
  rownames(sFF)<-unlist(lapply(annotations,function(a){paste(a$name,collapse=",")}))
  
  tindex2<-integer(0)
  labels2<-integer(0)
  if(!is.null(highlights) & length(highlights)>0){
    for(o in 1:length(highlights)){
      g<-grep(highlights[o],rownames(sFF))
      present<-which((g %in% tindex2))
      toadd<-which(!(g %in% tindex2))
      tindex2<-c(tindex2,g[toadd])
      labels2<-c(labels2,rep(highlights[o],length(toadd)))
      labels2[present]<-paste(labels2[present],highlights[o],sep=",")
    }
  }
  oo<-order(A$selected,A$class)
  A<-A[oo,]
  tindex2<-match(tindex2,oo)
  rsf<-range(sFF)
  if(rsf[1]<0 & rsf[2]>0){
    cfun<-colorRamp2(c(rsf[1], 0, rsf[2]), ecolors)
  }else if(rsf[2]>0){
    cfun<-colorRamp2(c(0, rsf[2]), ecolors[2:3])
  }else{
    cfun<-colorRamp2(c(rsf[1], 0), ecolors[1:2])
  }
  classnames<-c("CENTRALLY ENRICHED","TWO MERGED PEAKS","TWO OVERLAPPING PEAKS","TWO DISTINCT PEAKS","CONSTANTLY ENRICHED","CENTRALLY DEPLETED","CONSTANTLY DEPLETED")  
  classcolors<-setNames(RColorBrewer::brewer.pal(name = "Dark2", n = 7), classnames)	
  
  if(ismodel){
    row_ha<-rowAnnotation(
      Highlights=anno_mark(at=tindex2,labels=labels2,labels_gp=grid::gpar(fontsize = 8)),
      Model=anno_barplot(motifs@coefficients[oo],width=unit(2,"cm")),
      Baseline=anno_barplot(A$baseline,baseline=1,width=unit(2,"cm"),ylim=range(A$baseline)),
      Peak=anno_barplot(A$peak,width=unit(2,"cm"),ylim=c(0,max(max(A$peak),1))),
      Delta=anno_barplot(A$delta,baseline=0,ylim=c(0,max(max(A$delta),1))),
      Width=anno_barplot(A$width,ylim=c(0,max(max(A$width),1))),
      Cor=anno_barplot(A$cor,ylim=c(0,1))
    )
  }else{
    row_ha<-rowAnnotation(
      #       Highlights=anno_mark(at=tindex2,labels=labels2),
      #       Baseline=anno_barplot(A$baseline,baseline=1,width=unit(2,"cm"),ylim=range(A$baseline)),
      #       Peak=anno_barplot(A$peak,width=unit(2,"cm"),ylim=c(0,max(max(A$peak),1))),
      #       Delta=anno_barplot(A$delta,baseline=0,width=unit(2,"cm"),ylim=range(A$delta)),
      #       Width=anno_barplot(A$width,width=unit(2,"cm"),ylim=range(A$width)),
      #       Cor=anno_barplot(A$cor,width=unit(2,"cm")),
      #       width=unit(11,"cm")
      Highlights=anno_mark(at=tindex2,labels=labels2,labels_gp=grid::gpar(fontsize = 8)),
      Baseline=anno_barplot(A$baseline,baseline=1,ylim=range(A$baseline)),
      Peak=anno_barplot(A$peak,ylim=c(0,max(max(A$peak),1))),
      Delta=anno_barplot(A$delta,baseline=0,ylim=c(0,max(max(A$delta),1e-6))),
      Width=anno_barplot(A$width,ylim=c(0,max(max(A$width),1e-6))),
      Cor=anno_barplot(A$cor,ylim=c(0,1))
    )
  }
  row_ha_left<-rowAnnotation(
    Classification=A$class,
    annotation_legend_param = list(Classification = list(direction = "horizontal",nrow=4)),
    col=list(Classification=classcolors)
  )
  nn<-c("unselected","selected")
  dd<-data.frame(spec=nn[A$selected+1])
  h1<-Heatmap(sFF[oo,],name="Profile",row_split=dd,cluster_row_slices=FALSE,cluster_rows=FALSE,cluster_columns=FALSE,right_annotation=row_ha,left_annotation=row_ha_left,row_names_gp = grid::gpar(fontsize = 8),col=cfun,row_gap=unit(5,"mm"),heatmap_legend_param = list(direction = "horizontal"))
  draw(h1,heatmap_legend_side="bottom",padding = unit(c(10, 10, 10, 10), "mm"))
  h1
}

kdmGetPWM<-function(W,pwm0,tol=1e-4,max.iter=10000,use.float=FALSE){
  if(nrow(pwm0)==4){
    ret<-kdmGetPWM_internal(W,ncol(pwm0),as.numeric(pwm0),tol,max.iter,use.float)
    rownames(ret)<-c("A","C","G","T")
    ret
  }else{
    stop("pwm0 must be a 4 rows matrix")
  }
}

kdmGetProfileInfo<-function(motifs,regions,centers,labels,genomeFile,halfInterval,halfWin,tolerance=1e-10,strict,use_float){
  result<-kdmProfileInfo_internal(motifs,regions,centers,labels,genomeFile,halfInterval,halfWin,tolerance,strict,use_float)  
  result
}

kdmGetProfileInfoSeq<-function(motifs,pseq,nseq,halfInterval,halfWin,tolerance=1e-10,strict,use_float){
  result<-kdmProfileInfoSeq_internal(motifs,pseq,nseq,halfInterval,halfWin,tolerance,strict,use_float)  
  result
}

kdmCentrimo<-function(profileInfo,symmetric,tail,use_float=FALSE){
  
  res1<-kdmCentrimo_internal(profileInfo$pcounts,profileInfo$ncounts,ncol(profileInfo$phits),ncol(profileInfo$nhits),tail,symmetric,use_float);
  res2<-list()
  for(i in 1:length(res1)){
    res2[[i]]<-as.data.frame(res1[[i]])
    names(res2[[i]])<-c("Start","End","max_pos","mean_pos","np_in","np_out","nn_in","nn_out","Centrality","Centrality_p.value","Centrality_q.value","Enrichment","Enrichment_p.value","Enrichment_q.value")
  }
  res2
}

kdmIC<-function(W){
  ics<-rep(0,ncol(W))
  for(i in 1:ncol(W)){
    w<-as.numeric(W[,i]^2)
    
    sel<-which(w>0);
    ics[i]<- -log2(1/nrow(W))+sum(w[sel]*log2(w[sel]))
  }
  ics
}

kdmTomTargetInfo<-function(targetMotifs){
  IC<-function(W){
    ics<-rep(0,ncol(W))
    for(i in 1:ncol(W)){
      w<-as.numeric(W[,i]^2)
      
      sel<-which(w>0);
      ics[i]<- -log2(1/nrow(W))+sum(w[sel]*log2(w[sel]))
    }
    ics
  }
  targetInfo<-list(similarity=kdmSimilarity(targetMotifs,targetMotifs),ic=kdmIC(targetMotifs))
  WPAR<-data.frame(mean=rep(NA,ncol(targetMotifs)),sd=NA,Intercept=NA,Slope=NA)	
  MIC<-matrix(NA,ncol(targetMotifs),ncol(targetMotifs));
  for(i in 1:ncol(targetMotifs)){
    MIC[i,]<-sqrt(targetInfo$ic*targetInfo$ic[i])
    mm<-lm(targetInfo$similarity[i,]~MIC[i,])
    d<-targetInfo$similarity[i,]-predict(mm)
    
    # 		ss<-which(abs(d)<3*(sd(d)))
    # 		WPAR$mean[i]=mean(d[ss]);
    # 		WPAR$sd[i]=sd(d[ss]);
    
    WPAR$mean[i]=mean(d);
    WPAR$sd[i]=sd(d);
    
    WPAR$Intercept[i]=mm$coefficients[1];
    WPAR$Slope[i]=mm$coefficients[2];
  }
  targetInfo$WPAR<-WPAR
  targetInfo$mod<-lm(sd~ic,data=data.frame(ic=targetInfo$ic,sd=targetInfo$WPAR$sd))
  
  inf<-MIC[upper.tri(MIC)]
  sim<-targetInfo$similarity[upper.tri(targetInfo$similarity)]
  
  targetInfo$m2<-list()
  targetInfo$m2$mod<-lm(sim~inf)
  res<-resid(targetInfo$m2$mod)
  targetInfo$m2$mean<-mean(res)
  targetInfo$m2$sd<-sd(res)
  targetInfo
}

kdmTom<-function(queryMotifs, targetMotifs, correction.method="BH", threshold=0.5, select.by="qvalue", best.hit=FALSE, sort.by="similarity",targetInfo=NULL,targetSel=NULL){
  IC<-function(W){
    ics<-rep(0,ncol(W))
    for(i in 1:ncol(W)){
      w<-as.numeric(W[,i]^2)
      
      sel<-which(w>0);
      ics[i]<- -log2(1/nrow(W))+sum(w[sel]*log2(w[sel]))
    }
    ics
  }
  
  queryMotifs<-as(queryMotifs,"kdmotifs")
  targetMotifs<-as(targetMotifs,"kdmotifs")
  if(length(colnames(targetMotifs))!=ncol(targetMotifs)){
    colnames(targetMotifs)<-1:ncol(targetMotifs)
  }
  
  if(length(colnames(queryMotifs))!=ncol(queryMotifs)){
    colnames(queryMotifs)<-1:ncol(queryMotifs)
  }
  
  tinfo<-if(is.null(targetInfo)){
    tinfo<-kdmTomTargetInfo(targetMotifs);
  }else{
    targetInfo
  }
  
  
  icst<-tinfo$ic
  tnames<-colnames(targetMotifs)
  
  SQ<-kdmSimilarity(queryMotifs,targetMotifs)
  icsq<-kdmIC(queryMotifs)
  qnames<-colnames(queryMotifs)
  
  WPAR<-tinfo$WPAR
  
  PV<-QV<-EV<-matrix(NA,nrow(SQ),ncol(SQ))
  for(i in 1:nrow(SQ)){
    mm<-lm(SQ[i,]~sqrt(icst*icsq[i]))
    d<-SQ[i,]-predict(mm)
    PV[i,]=pnorm(d,WPAR$mean,WPAR$sd,lower.tail=FALSE)
    QV[i,]=p.adjust(PV[i,],method=correction.method)
    EV[i,]=PV[i,] * (2*ncol(targetMotifs))
  }
  dd<-c()
  if(!best.hit){
    tot<-0;
    OO<-c()
    if(select.by=="qvalue"){
      OO<-QV;
    }else if(select.by=="pvalue"){
      OO<-PV
    }else if(select.by=="evalue"){
      OO<-EV;
    }else if(select.by=="similarity"){
      OO<-SQ;
    }
    
    for(i in 1:nrow(PV)){
      ss<-which(OO[i,]<threshold)		
      tot<-tot+length(ss)
    }
    if(tot>0){
      dd<-data.frame(query=rep("",tot),target=rep("",tot),p.value=NA,q.value=NA,e.value=NA,similarity=NA)		
      ccount<-1
      for(i in 1:nrow(OO)){
        sel<-which(OO[i,]<threshold)
        if(sort.by=="similarity"){
          oo<-sel[order(SQ[i,sel],decreasing=TRUE)]
        }else if(sort.by=="pvalue"){
          oo<-sel[order(PV[i,sel])]
        }else if(sort.by=="qvalue"){
          oo<-sel[order(QV[i,sel])]
        }else if(sort.by=="evalue"){
          oo<-sel[order(EV[i,sel])]
        }
        if(length(oo)>0){
          dd[ccount:(ccount+length(oo)-1),]<-data.frame(query=rep(qnames[i],length(oo)),target=tnames[oo],p.value=PV[i,oo],q.value=QV[i,oo],e.value=EV[i,oo],similarity=SQ[i,oo]);
        }
        ccount<-ccount+length(oo)
      }
    }else{
      dd<-c()
    }
  }else{
    dd<-data.frame(query=qnames,target="none",p.value=NA,q.value=NA,e.value=NA,similarity=NA)
    for(i in 1:nrow(PV)){
      ss<-ncol(QV)
      if(select.by=="qvalue"){
        ss<-which(QV[i,]<threshold)		
      }else if(select.by=="pvalue"){
        ss<-which(PV[i,]<threshold)		
      }else if(select.by=="evalue"){
        ss<-which(EV[i,]<threshold)		
      }else if(select.by=="similarity"){
        ss<-which(SQ[i,]<threshold)		
      }
      if(length(ss)>0){
        if(sort.by=="similarity"){
          sel<-ss[which.max(SQ[i,ss,drop=FALSE])]
        }else if(sort.by=="qvalue"){
          sel<-ss[which(QV[i,ss]==min(QV[i,ss]))]
          if(length(sel)>1){
            sel<-sel[which.max(SQ[i,sel])]
          }
        }else if(sort.by=="evalue"){
          sel<-ss[which(EV[i,ss]==min(EV[i,ss]))]
          if(length(sel)>1){
            sel<-sel[which.max(SQ[i,sel])]
          }
        }else if(sort.by=="pvalue"){
          sel<-ss[which.min(PV[i,ss])]
        }
        dd$target[i]<-tnames[sel]
        dd$p.value[i]<-PV[i,sel]
        dd$q.value[i]<-QV[i,sel]
        dd$e.value[i]<-EV[i,sel]
        dd$similarity[i]<-SQ[i,sel]
      }
    }
  }
  nn<-colnames(queryMotifs)
  dd$rank<-NA
  for(r in 1:ncol(queryMotifs)){
    s1<-which(dd$query==nn[r])
    if(length(s1)>0){
      dd$rank[s1]<-1:length(s1)
    }
  }
  dd
}


ENCODEsequences<-function(sequences,dictionary,win.mod=NULL){
    V<-list()
    if(is.null(win.mod)){
        V[[1]]<-kdmDistr(data=sequences,kmerlength=dictionary$kmerlength,ngaps=dictionary$ngaps,double.strand=dictionary$double.strand)
        names(V)<-"coefficients"
    }else{
        if(sum(nchar(sequences)<max(win.mod$end))>0){
          stop("All sequences must be longer than the max win_mod end")
        }
        tmpV<-list()
        for(i in 1:nrow(win.mod)){
            tmpV[[i]]<-kdmDistr(data=substr(sequences,win.mod$start[i],win.mod$end[i]),kmerlength=dictionary$kmerlength,ngaps=dictionary$ngaps,double.strand=dictionary$double.strand)
        }
        groups<-sort(unique(win.mod$group))
        
        for(i in 1:length(groups)){
            sel<-which(win.mod$group==groups[i])
            M<-matrix(0,nrow(tmpV[[1]]),ncol(tmpV[[1]])) 
            for(j in 1:length(sel)){
                M<-M+tmpV[[sel[j]]]^2
            }
            M<-sqrt(M/length(sel))
            V[[i]]<-new("kdistr",M,l=tmpV[[1]]@l,k=tmpV[[1]]@k,doubleStrand=tmpV[[1]]@doubleStrand,estimated=tmpV[[1]]@estimated)
        }
        names(V)<-groups
    }
    V
}

#' Define a k-mer dictionary
#'
#' Defines the dictionary of k-mers on which motifs, sequences and scores are
#' represented. It is the first choice to make in a KDM analysis, since
#' everything downstream lives in the space defined by the dictionary.
#'
#' @param kmerlength integer, the length of the k-mers. Undefined positions
#'   (gaps) are included in this length.
#' @param ngaps integer in \code{[0, kmerlength)}, the number of undefined
#'   positions (gaps, written \code{N}) in each k-mer.
#' @param double.strand logical. If \code{TRUE}, the dictionary is double
#'   strand: each k-mer and its reverse complement are considered the same
#'   entity. If \code{FALSE}, all k-mers are distinct.
#'
#' @return A list containing:
#' \itemize{
#'   \item \code{kmerlength}, \code{ngaps}, \code{double.strand}: the
#'     parameters used to define the dictionary.
#'   \item \code{kmers}: a data.frame listing the k-mers in the dictionary.
#'     It has one column (\code{kmer}) if \code{double.strand=FALSE}, and two
#'     columns (\code{kmer} and \code{kmer_rc}, the reverse complement) if
#'     \code{double.strand=TRUE}.
#' }

KDMDictionary<-function(kmerlength,ngaps,double.strand){
	wrds<-kdmGkmersString(kmerlength,ngaps,double.strand)
	if(!double.strand){
		colnames(wrds)="kmer"
	}else{
		colnames(wrds)=c("kmer","kmer_rc")
	}
	list(kmerlength=kmerlength,ngaps=ngaps,double.strand=double.strand,kmers=wrds)
}



#' Discover KDM motifs de novo from a set of sequences
#'
#' Performs unsupervised KDM finding on a set of sequences by factorizing
#' their k-mer representation with Projective Non-negative Matrix
#' Factorization (PNMF). The sequences are encoded with the given k-mer
#' dictionary and the factorization is initialized by hierarchical
#' clustering. If a range of ranks is given, the number of motifs is chosen
#' as the rank with the highest average silhouette score.
#'
#' @param sequences an array of sequences. They do not need to have the same
#'   length, but must be longer than the k-mer length of the dictionary.
#' @param minrank integer, the minimum factorization rank allowed (i.e. the
#'   minimum number of motifs). It must not be greater than \code{maxrank}.
#' @param maxrank integer in \code{[1, number of sequences]}, the maximum
#'   factorization rank allowed (i.e. the maximum number of motifs). If equal
#'   to \code{minrank}, that rank is used without testing others.
#' @param dictionary the dictionary defining the k-mer space, as returned by
#'   \code{\link{KDMDictionary}}.
#' @param tol double, the stopping criterion of the factorization iterations.
#'   Default 1e-6.
#'
#' @return An object of class \code{kdmotifs}: a matrix of size
#'   \code{[nkmers x rank]}. Each column contains the Hellinger-transformed
#'   probability distribution of a motif over the k-mers of the dictionary.
#'   The columns are named \code{M-1}, \code{M-2}, and so on.

KDMFind<-function(sequences,minrank,maxrank,dictionary,tol=1e-6){
    encodings<-ENCODEsequences(sequences,dictionary,win.mod=NULL)[[1]]
    if(minrank<maxrank){
        W0<-kdmGetW0(encodings,"complete",good.clusters=FALSE,min.rank=minrank,max.rank=maxrank,bhattacharyya=FALSE,use.float=FALSE)
        W<-kdmMotifs(encodings,ncol(W0$W0),0,initialization="custom",W0=W0$W0,tolerance=tol)
    }else if(minrank==maxrank){
        W<-kdmMotifs(encodings,minrank,0,initialization="cluster",tolerance=tol)
    }else{
        stop("minrank must be <= maxrank")
    }
    colnames(W)<-paste("M-",1:ncol(W),sep="")
    if(dictionary$double.strand){
      rownames(W)<-apply(dictionary$kmers,1,paste0,collapse="|")
    }else{
      rownames(W)<-dictionary$kmers$kmer
    }
    W
}


#' Motif enrichment and positional distribution
#'
#' Performs the positional enrichment analysis of a set of motifs, comparing
#' bound against unbound sequences within a sliding window. For each motif,
#' it tests whether its best matches are centrally distributed along the
#' sequences and enriched in the bound sequences.
#'
#' @param motifs a \code{kdmotifs} object obtained from \code{\link{KDMFind}}.
#' @param pseq an array of sequences: a set of equal length bound sequences.
#' @param nseq an array of sequences: a set of equal length unbound sequences.
#'   The sequence length must be the same as in \code{pseq}.
#' @param halfWin integer, defines the size of the sliding window used to
#'   calculate the signal along the provided sequences. The actual window
#'   size is \code{2*halfWin + 1}.
#' @param sig.level the significance level at which a motif is considered
#'   centrally enriched. Default 0.05.
#' @param experiment.type string, either \code{"ChIP"} or \code{"Clip"}. It
#'   defines the regions along the sequences that are considered "central".
#'   Use \code{"ChIP"} for DNA sequences: only the region centred exactly on
#'   the sequence centre is tested. Use \code{"Clip"} for RNA sequences:
#'   every region whose centre is at or before the sequence centre is tested.
#'   Default \code{"ChIP"}.
#'
#' @return A list containing two elements:
#' \itemize{
#'   \item \code{results}: a data.frame with the motifs identified as both
#'     centrally distributed and enriched in the bound sequences (empty if
#'     there are none). Its columns are:
#'     \itemize{
#'       \item \code{motif}: name of the motif.
#'       \item \code{Start}, \code{End}: the boundaries of the region in which
#'         the motif shows higher values of PE and CE.
#'       \item \code{bin_location}: the centre of the region.
#'       \item \code{PE}: Positional Enrichment, the fraction of
#'         bound-sequence hits that fall inside the region, divided by the
#'         fraction expected under a uniform positional distribution:
#'         \code{PE = (Hr,pos / Hs,pos) / p0}, with \code{p0 = Lr / Ls}, the
#'         region length over the sequence length.
#'       \item \code{CE}: Class Enrichment, the fraction of bound sequences
#'         with a hit in the region, divided by the same fraction in the
#'         unbound sequences: \code{CE = (Hr,pos / Npos) / p0}, with
#'         \code{p0 = Hr,neg / Nneg}, where \code{Npos} and \code{Nneg} are
#'         the numbers of bound and unbound sequences.
#'       \item \code{motif_auroc}: the AUROC of the motif's maximum score per
#'         sequence, discriminating bound from unbound sequences. It is
#'         reported as \code{-(1 - AUROC)} when the motif scores higher in
#'         the unbound sequences, so its absolute value is always >= 0.5 and
#'         its sign gives the direction.
#'       \item \code{PE_p.value}, \code{PE_q.value}: significance of PE: an
#'         upper-tail binomial test p-value, and its multiple-testing
#'         corrected q-value.
#'       \item \code{CE_p.value}, \code{CE_q.value}: significance of CE: an
#'         upper-tail binomial test p-value with \code{Hr,pos} successes out
#'         of \code{Npos} trials, and its multiple-testing corrected q-value.
#'       \item \code{np_in}, \code{np_out}: number of hits inside and outside
#'         the region for bound sequences. \code{np_in} is \code{Hr,pos}, and
#'         \code{np_in + np_out} is \code{Hs,pos}.
#'       \item \code{nn_in}, \code{nn_out}: number of hits inside and outside
#'         the region for unbound sequences. \code{nn_in} is \code{Hr,neg}.
#'     }
#'   \item \code{profiles}: a list containing the scores (\code{signal}) and
#'     the number of hits (\code{hits}) of all the motifs along all the
#'     sequences, for the bound and unbound sets. It can be used to visualize
#'     the centrality profiles (see \code{plot.motif.map}).
#' }
#'

KDMMap<-function(motifs,pseq,nseq,halfWin,sig.level=0.05,experiment.type="ChIP"){
    if(!(experiment.type %in% c("ChIP","Clip"))){
        stop("experiment.type must be \"Clip\" or \"ChIP\"")
    }

    rr<-range(nchar(c(pseq,nseq)))
    if(rr[1]!=rr[2]){
        stop("All sequences must have the same length")
    }
    halfInterval=(rr[1]-1)/2
    pinfo<-kdmGetProfileInfoSeq(motifs=motifs,pseq=pseq,nseq=nseq,halfInterval=halfInterval,halfWin=halfWin,tolerance = 1e-10,strict = FALSE,use_float=FALSE)
	tmp<-data.frame(motif=NA,Start=NA,End=NA,max_pos=NA,np_in=NA,np_out=NA,nn_in=NA,nn_out=NA,Centrality=NA,Centrality_p.value=NA,Centrality_q.value=NA,Enrichment=NA,Enrichment_p.value=NA,Enrichment_q.value=NA,bin_location=NA)
	edf<-tmp[which(!is.na(tmp$motif)),]
	nmotifs<-length(pinfo$pfeat)
	centrimo<-kdmCentrimo(pinfo, symmetric = FALSE, tail = "upper")
	res<-c()
	for(mn in 1:nmotifs){
		E<-centrimo[[mn]]
		E$Start<-E$Start+pinfo$x[1]
		E$End<-E$End+pinfo$x[1]
		E$max_pos<-E$max_pos+pinfo$x[1]
		E$mean_pos<-E$mean_pos+pinfo$x[1]
		E$bin_location<-(E$End+E$Start)/2
		if(experiment.type=="ChIP"){
            E<-E[which(E$bin_location==0),]
        }else if(experiment.type=="Clip"){
            E<-E[which(E$bin_location<=0),]
        }
		
		E$Centrality_q.value<-p.adjust(E$Centrality_p.value,method="fdr")
		E$Enrichment_q.value<-p.adjust(E$Enrichment_p.value,method="fdr")

   		sel<-which( ((E$Centrality_q.value * nmotifs) < sig.level) & E$Centrality>1 & ((E$Enrichment_q.value * nmotifs) < sig.level) & E$Enrichment >1)
		if(length(sel)>0){
			oo<-sel[
                order(
                    rank(-log10(E$Centrality_q.value[sel]))+rank(-log10(E$Enrichment_q.value[sel])),
                    -log10(E$Centrality_q.value[sel])
                    ,decreasing=TRUE
                    )
            ]
			res<-rbind(res,data.frame(motif=mn,E[oo[1],]))
		}
	}
	if(!is.null(res)){
		res<-res[order(rank(-log10(res$Centrality_q.value))+rank(-log10(res$Enrichment_q.value)),-log10(res$Centrality_q.value),decreasing=TRUE),]
		res$motif<-colnames(motifs)[res$motif]
	}else{
		res<-edf
	}

	profiles<-list()
	profiles$signal<-list()
	profiles$signal$x<-pinfo$x
	profiles$signal$positive<-matrix(unlist(lapply(pinfo$pfeat,function(x){apply(x,2,mean)})),length(pinfo$pfeat),length(pinfo$x),byrow=TRUE)
	rownames(profiles$signal$positive)<-colnames(motifs)
	profiles$signal$negative<-matrix(unlist(lapply(pinfo$nfeat,function(x){apply(x,2,mean)})),length(pinfo$nfeat),length(pinfo$x),byrow=TRUE)
	rownames(profiles$signal$negative)<-colnames(motifs)
	
	
	profiles$hits<-list()
	profiles$hits$x<-pinfo$x[2:(length(pinfo$x)-1)]
	profiles$hits$positive<-pinfo$pcounts
	rownames(profiles$hits$positive)<-colnames(motifs)
	profiles$hits$negative<-pinfo$ncounts
	rownames(profiles$hits$negative)<-colnames(motifs)
	
	profiles$aurocs<-pinfo$aurocs
	profiles$thresholds<-pinfo$thresholds
	res$motif_auroc<-profiles$aurocs[match(res$motif,colnames(motifs))]
	res<-res[,c("motif","Start","End","bin_location","Centrality","Enrichment","motif_auroc","Centrality_p.value","Centrality_q.value","Enrichment_p.value","Enrichment_q.value","np_in","np_out","nn_in","nn_out")]
	colnames(res)<-c("motif","Start","End","bin_location","PE","CE","motif_auroc","PE_p.value","PE_q.value","CE_p.value","CE_q.value","np_in","np_out","nn_in","nn_out")
	list(results=res,profiles=profiles)
}


#' Plot centrality and enrichment of a motif
#'
#' Plots the positional distribution of a single motif around the centre of
#' the analysed regions, comparing positive and negative regions.
#'
#' @param centrality the list returned by \code{\link{KDMMap}}.
#' @param motif.name character. Name of the motif to plot.
#'
#' @return A ggpubr object containing a two-panel figure: the top panel shows
#'   the average signal profile, the bottom panel the number of motif hits at
#'   each position.
plot.motif.map<-function(centrality,motif.name){
  profiles<-centrality$profiles
  id<-which(rownames(profiles$signal$positive)==motif.name)
  if(length(id)==0){
    stop("Motif not present")
  }
  spos<-profiles$signal$positive[id,]
  sneg<-profiles$signal$negative[id,]
  hpos<-profiles$hits$positive[id,]
  hneg<-profiles$hits$negative[id,]

  dd<-data.frame(Position=c(profiles$signal$x,profiles$signal$x),Signal=c(spos,sneg),Group=c(rep("Positives",length(spos)),rep("Negatives",length(sneg))))
  p1<-ggplot2::ggplot(dd,ggplot2::aes(x=Position,y=Signal,color=Group)) + ggplot2::geom_line()

  dd<-data.frame(Position=c(profiles$hits$x,profiles$hits$x),Hits=c(hpos,hneg),Group=c(rep("Positives",length(hpos)),rep("Negatives",length(hneg))))
  p2<-ggplot2::ggplot(dd,ggplot2::aes(x=Position,y=Hits,fill=Group)) + ggplot2::geom_col(position = "identity",alpha=0.5)

  plot<-ggpubr::ggarrange(p1,p2,common.legend=TRUE,legend="right")
  plot
}

#' Classify motifs against a reference set of known motifs
#'
#' Annotates the discovered motifs by information-content-aware matching
#' against a reference set already embedded in KDM space. The similarity
#' between query and target motifs is adjusted for the information content
#' (IC) of the target motifs, so that generic, low-information motifs do not
#' appear similar to everything.
#'
#' @param query.motifs a \code{kdmotifs} object obtained from
#'   \code{\link{KDMFind}} containing the motifs to classify.
#' @param target.motifs a \code{kdmotifs} object containing the motifs against
#'   which the query is classified.
#' @param target.parameters optional. An object obtained through the helper
#'   function \code{\link{buildKDMReference}}, containing the parameters of
#'   the linear models used to correct for the IC content of the target
#'   motifs. If \code{NULL} (default), they are estimated from
#'   \code{target.motifs}.
#' @param best.hit logical. If \code{TRUE}, the function reports only the best
#'   hit for each query motif. Otherwise, it reports all the matches for each
#'   motif. Default \code{FALSE}.
#' @param threshold the significance level at which matches are reported.
#'   Default 0.05.
#'
#' @return A data.frame containing the matching information, with columns:
#' \itemize{
#'   \item \code{query}: the name of the query motif.
#'   \item \code{target}: the name of the matching target motif.
#'   \item \code{p.value}: the p-value of the match.
#'   \item \code{q.value}: the Bonferroni-corrected p-value (it depends on the
#'     number of target motifs).
#'   \item \code{similarity}: the similarity between the query and the target
#'     motifs.
#'   \item \code{rank}: for each query motif, the similarity rank of the
#'     target (1 is the most similar). If \code{best.hit=TRUE} it is always 1.
#' }
#' If there are no significant matches, the character string
#' \code{"No significant match"} is returned instead.

KDMMatch<-function(query.motifs,target.motifs,target.parameters=NULL,best.hit=FALSE,threshold=0.05){
    aa<-kdmTom(query.motifs,target.motifs,best.hit=best.hit,threshold=threshold,targetInfo=target.parameters)
    if(length(aa)>1){
        aa<-aa[,c(-5)]
    }else{
      aa<-"No significant match"
    }
    aa
}


#' Train a KDM-LRLM binding prediction model
#'
#' Turns the discovered motifs into a binding predictor using a KDM-based
#' Lasso-Regularized Logistic Model (KDM-LRLM), trained to distinguish
#' positive from negative sequences (e.g. bound vs. unbound). For each
#' sequence, the features are the scores of the input motifs, optionally
#' computed separately on different regions (windows). A logistic regression
#' with L1 (Lasso) penalty is then fitted: the penalty drives most motif
#' coefficients to exactly zero, so the fitted model is also a selection of
#' the motifs that matter.
#'
#' KDM-LRLM is implemented in three functions: \code{KDM.LRLM.train} to train
#' the model, \code{\link{KDM.LRLM.performance}} to evaluate its predictive
#' performance, and \code{\link{KDM.LRLM.predict}} to predict bound
#' sequences.
#'
#' @param motifs a \code{kdmotifs} object containing the motifs used to build
#'   the features.
#' @param pseq a set of "positive" (i.e. bound) sequences used for training.
#' @param nseq a set of "negative" (i.e. unbound) sequences used for training.
#' @param win.mod optional. A data.frame defining the regions the sequences
#'   are split into, in order to obtain the features on which the model is
#'   identified. It has one row per region and must contain: \code{start},
#'   the starting position of the region; \code{end}, the ending position of
#'   the region; and \code{group}, the group the region belongs to. Features
#'   on regions of the same group are collapsed into a single one (useful
#'   for ChIP-seq derived sequences in which distal regions are equivalent),
#'   so the model has one coefficient per motif and per group. If
#'   \code{NULL} (default), each sequence is used as a whole.
#' @param nfold the number of folds used internally by
#'   \code{\link[glmnet]{cv.glmnet}} for cross-validation, to choose the
#'   regularization parameter. Default 10.
#' @param seed the seed used for cross-validation by
#'   \code{\link[glmnet]{cv.glmnet}}, for reproducibility. Default 100.
#'
#' @return A list containing:
#' \itemize{
#'   \item \code{motifs}: a \code{kdmotifs} object with the motifs retained by
#'     the model (non-zero coefficient in at least one group).
#'   \item \code{coefficients}: a data.frame with the model coefficients of
#'     the retained motifs (rows), organized by columns, each corresponding
#'     to a group as defined in \code{win.mod}.
#'   \item \code{intercept}: the intercept of the model.
#'   \item \code{win.mod}: the input \code{win.mod} parameter, reported back.
#' }

KDM.LRLM.train<-function(motifs,pseq,nseq,win.mod=NULL,nfold=10,seed=100){
    dictionary<-list(kmerlength=motifs@l,ngaps=motifs@k,double.strand=motifs@doubleStrand)
    sequences<-c(pseq,nseq)
    labels<-c(rep(1,length(pseq)),rep(0,length(nseq)))
    ENCODED<-ENCODEsequences(sequences,dictionary,win.mod)
    Features<-c() 
    for(i in 1:length(ENCODED)){
        Features<-cbind(Features,kdmFeatures(motifs=motifs,data=ENCODED[[i]]))
    }
    s="lambda.min"
    set.seed(seed)
    m<-glmnet::cv.glmnet(y=labels,x=Features,family="binomial",type.measure="auc",nfold=nfold)
    nwin<-max(1,length(unique(win.mod$group)))
    coefficients<-matrix(coef(m,s=s)[2:((ncol(motifs)*nwin)+1)],ncol(motifs),nwin)
    intercept<-coef(m,s=s)[1]
    
    selected<-which(apply(coefficients,1,function(x){sum(x!=0)})>0)
    selectedMotifs<-motifs[,selected]
    coefficients<-as.data.frame(coefficients[selected,,drop=FALSE])
    colnames(coefficients)<-names(ENCODED)
    rownames(coefficients)<-colnames(motifs[,selected])
  
    list(motifs=selectedMotifs,coefficients=coefficients,intercept=intercept,win.mod=win.mod)
}

#' Evaluate the performance of a KDM-LRLM model
#'
#' Computes the predictive performance of a KDM-LRLM model: a set of positive
#' (bound) and negative (unbound) sequences is scored with the model, and
#' standard classification performance measures are computed.
#'
#' @param model the model returned by \code{\link{KDM.LRLM.train}}.
#' @param pseq a set of "positive" (i.e. bound) sequences used to evaluate
#'   the model.
#' @param nseq a set of "negative" (i.e. unbound) sequences used to evaluate
#'   the model.
#'
#' @return A named numeric array with three values: \code{AUROC}, the area
#'   under the ROC curve; \code{AUPRC}, the area under the Precision-Recall
#'   curve; and \code{ACCURACY}, the highest accuracy over all possible score
#'   thresholds.
KDM.LRLM.performance<-function(model,pseq,nseq){
    sequences<-c(pseq,nseq)
    labels<-c(rep(1,length(pseq)),rep(0,length(nseq)))
    p<-KDM.LRLM.predict(model,sequences)
    ACC<-max(ROCR::performance(ROCR::prediction(labels=labels,predictions=p$score),"acc")@y.values[[1]])
    AUROC<-ROCR::performance(ROCR::prediction(labels=labels,predictions=p$score),"auc")@y.values[[1]]
    AUPRC<-ROCR::performance(ROCR::prediction(labels=labels,predictions=p$score),"aucpr")@y.values[[1]]
    c(AUROC=AUROC,AUPRC=AUPRC,ACCURACY=ACC)
}

#' Apply a KDM-LRLM model to new sequences
#'
#' Uses a model trained with \code{\link{KDM.LRLM.train}} to analyse any
#' sequence of interest. For each sequence, it returns the model score
#' (higher scores mean a higher likelihood of belonging to the positive
#' class, i.e. the one given as \code{pseq} at training time), the
#' corresponding predicted class, and the motif scores used as features.
#'
#' @param model a model obtained by \code{\link{KDM.LRLM.train}}.
#' @param sequences a character array containing the N sequences to be
#'   analysed. All sequences must be long enough to accommodate at least one
#'   window defined in \code{model$win.mod}.
#' @param sliding logical. If \code{TRUE}, each sequence is spanned with
#'   sliding windows defined in \code{model$win.mod}. If \code{FALSE}
#'   (default), the analysis of each sequence is performed on its first part
#'   only.
#'
#' @return If \code{sliding} is \code{FALSE}, a list containing:
#' \itemize{
#'   \item \code{score}: a column array containing the model scores.
#'   \item \code{class}: an array containing the predicted classes: 1 for the
#'     positive class, 0 for the negative class.
#'   \item \code{features}: a named list containing, for each group defined
#'     in \code{model$win.mod}, a matrix (N x number of motifs in the model)
#'     with the score of each motif for each sequence.
#' }
#' If \code{sliding} is \code{TRUE}, a list containing, for each sequence, the
#' same list described above, where the sequences are obtained by sliding
#' \code{model$win.mod} along the provided sequences.

KDM.LRLM.predict<-function(model,sequences,sliding=FALSE){
    dictionary<-list(kmerlength=model$motifs@l,ngaps=model$motifs@k,double.strand=model$motifs@doubleStrand)

    if(sliding){
      res<-list()
      for(i in 1:length(sequences)){
        seq<-sequences[i]
        actual_seqs<-unlist(sapply(1:(nchar(seq)-max(model$win.mod$end)-1),function(s){substr(seq,s,s+300)}))
        ENCODEDsequences<-ENCODEsequences(actual_seqs,dictionary,model$win.mod)
        Features<-c() 
        Features2<-list()
        for(k in 1:length(ENCODEDsequences)){
          Features2[[k]]<-kdmFeatures(motifs=model$motifs,data=ENCODEDsequences[[k]])
          Features<-cbind(Features,Features2[[k]])
        }
        names(Features2)<-names(ENCODEDsequences)
        score<-Features %*% as.numeric(as.matrix(model$coefficients)) + model$intercept
        class<-as.numeric(score>0)
        res[[i]]<-list(score=score,class=class,features=Features2)
      }
    }else{
      ENCODEDsequences<-ENCODEsequences(sequences,dictionary,model$win.mod)
      Features<-c() 
      Features2<-list()
      for(k in 1:length(ENCODEDsequences)){
        Features2[[k]]<-kdmFeatures(motifs=model$motifs,data=ENCODEDsequences[[k]])
        Features<-cbind(Features,Features2[[k]])
      }
      names(Features2)<-names(ENCODEDsequences)
      score<-Features %*% as.numeric(as.matrix(model$coefficients)) + model$intercept
      class<-as.numeric(score>0)
      res<-list(score=score,class=class,features=Features2)
    }
    res
}

#' Build a reference collection of KDM motifs
#'
#' Builds an annotated reference collection of KDM motifs, to be used to
#' classify the discovered motifs with \code{\link{KDMMatch}}. The motifs can
#' be provided directly as KDMs, or as PWMs in a MEME file, in which case they
#' are transformed into KDMs using the given dictionary.
#'
#' @param motifs either the name of a MEME file containing PWM definitions, or
#'   an object of class \code{kdmotifs}.
#' @param dictionary the dictionary used to transform PWMs into KDMs, as
#'   returned by \code{\link{KDMDictionary}}. It is used only when
#'   \code{motifs} is a MEME file.
#' @param info optional. A data.frame with one row per motif. It must contain
#'   a \code{name} column with the names to assign to the motifs, and it can
#'   contain other columns of your choice (e.g. the protein to which each
#'   motif is associated, or the experiment from which the motif comes). If
#'   \code{NULL} (default), the motifs are named \code{REF-1}, \code{REF-2},
#'   and so on.
#'
#' @return A list containing:
#' \itemize{
#'   \item \code{motifs}: the \code{kdmotifs} object representing the motifs.
#'   \item \code{info}: the \code{info} data.frame passed as input.
#'   \item \code{parameters}: an object containing the parameters of the
#'     linear models used to correct for the information content (IC) of the
#'     target motifs. It can be passed as \code{target.parameters} to
#'     \code{\link{KDMMatch}}.
#' }

buildKDMReference<-function(motifs,dictionary,info=NULL){
  if(class(motifs)[1]=="kdmotifs"){
      kdms<-motifs
  }else if(class(motifs)[1]=="character"){
      kdms<-PWM2KDM(motifs,dictionary)
  }else{
    stop("motifs must be either the name of a meme file (for PWM) or an object of class kdmotifs")
  }
  if(!is.null(info)){
    if(nrow(info)==ncol(kdms)){
      colnames(info)<-info$name
    }else{
      stop("info must have the same number of rows as the number of motifs")
    }
  }else{
    if(is.null(colnames(kdms))){
      colnames(kdms)<-paste0("REF-",1:ncol(kdms))
    }
  }
  parameters<-kdmTomTargetInfo(kdms)
  list(motifs=kdms,info=info,parameters=parameters)
}


PWM2KDM<-function(meme_file,dictionary){
  pwm<-kdmLoadPWMSet(filename=meme_file)
  kdmMotifsFromPWM(pwm,dictionary$kmerlength,dictionary$ngaps,dictionary$double.strand,pad.size=dictionary$kmerlength-1)
}

